public interface PaymentStrategy {
    void processPayment(double amount);
}