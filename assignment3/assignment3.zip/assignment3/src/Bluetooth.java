public class Bluetooth implements AudioSource {
    private String name = "Bluetooth Audio";

    public String getName() {
        return name;
    }
}