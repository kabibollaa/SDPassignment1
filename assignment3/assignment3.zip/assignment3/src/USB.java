public class USB implements AudioSource {
    private String name = "USB Audio";

    public String getName() {
        return name;
    }
}