// Audio source interfaces
public interface AudioSource {
    String getName();
}