// Client interface (Car Audio System)
public interface CarAudioSystem {
    void playAudio(AudioSource audioSource);
}